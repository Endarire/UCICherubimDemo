A Pen created at CodePen.io. You can find this one at https://codepen.io/jackw/pen/FxBky.

 Experimenting with sass maps, loops and css3 stuff. 
I can't remember where I saw the inspiration for this. It was a gif somewhere and was slightly more awesome.