A Pen created at CodePen.io. You can find this one at https://codepen.io/Mark_Bowley/pen/xEbuI.

 Animated clouds using nothing but HTML and CSS.